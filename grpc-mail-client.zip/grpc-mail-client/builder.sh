#!/usr/bin/env bash
mvn clean package --settings=/Users/qiding/systemtools/maven/apache-maven-3.5.4/conf/settings-home.xml